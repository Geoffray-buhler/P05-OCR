<?php

namespace Bdd;

class Config {
   /**
    * path to the sqlite file
    */
    const PATH_TO_SQLITE_FILE = './phpsqlite.db';
}