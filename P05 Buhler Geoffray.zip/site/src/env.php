<?php

$Host       = 'node44-eu.n0c.com';
$Username   = 'contact@griffont39.yn.lu';
$Password   = 'HUB10base-t39';
